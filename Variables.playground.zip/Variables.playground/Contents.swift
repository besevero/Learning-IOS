var user: String = "Michael Scott"
var calories: Int = 2400

print(user)
print(calories)

user = "Dwight Schrute"
print(user)

var dailyCaloriesWomen = 2000
var dailyCaloriesMen = 2500

