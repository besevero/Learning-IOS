let x = 4
let y = 2

var z = x + y

print(z)

z = x - y
print(z)

z = x * y
print(z)

z = x / y
print(z)

z = x + x * y - y
print(z)
