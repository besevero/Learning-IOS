var number = 1000
let expanse = 1200

if number % 2 == 0{
    
}

let traffiLight = "Green"
if traffiLight == "Green"{
    print("Go!")
}else if traffiLight == "Yellow"{
    print("Slow down")
}else if traffiLight == "Red"{
    print("Stop")
}


