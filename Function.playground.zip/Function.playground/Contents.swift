func printHello(){
    print("Hello!")
}

func squareArea(sideA: Double) -> Double{
    return sideA * sideA
}

printHello()
let area = squareArea(sideA: 2.2)
print(area)
